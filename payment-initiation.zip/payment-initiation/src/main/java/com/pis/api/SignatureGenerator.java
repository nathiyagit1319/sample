package com.pis.api;

import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.KeyFactory;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.Signature;
import java.security.SignatureException;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import org.apache.commons.codec.binary.Base64;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import com.pis.api.model.PaymentInitiationRequest;
/**
 * 
 * Signature Generator Class for generate signature
 *
 */
@Component
public class SignatureGenerator {
	@Value("${value.xrequestid}")
	String xRequestId;
	@Value("${value.privatekey}")
	String privateKey;
	@Value("${value.debtoriban}")
	String debtorIBAN;
	@Value("${value.creditoriban}")
	String creditorIBAN;
	@Value("${value.amount}")
	String amount;
	@Value("${value.currency}")
	String currency;
	@Value("${value.endtoendid}")
	String endToEndId;

	public String generateSignature() throws NoSuchAlgorithmException, InvalidKeySpecException, InvalidKeyException,
			SignatureException, IOException {

		Signature signatureAlgorithm = Signature.getInstance("SHA256withRSA");
		byte[] privateKeyBase64Input = Base64.decodeBase64(privateKey);
		PKCS8EncodedKeySpec privateKeyEncoded = new PKCS8EncodedKeySpec(privateKeyBase64Input);

		KeyFactory keyFactory = KeyFactory.getInstance("RSA");
		PrivateKey privateKey = keyFactory.generatePrivate(privateKeyEncoded);
		signatureAlgorithm.initSign(privateKey);

		BufferedInputStream bufferInputStream = new BufferedInputStream(new ByteArrayInputStream(xRequestId.getBytes()));
		byte[] input = new byte[1024];
		int length;
		while ((length = bufferInputStream.read(input)) >= 0) {
			signatureAlgorithm.update(input, 0, length);
		}
		bufferInputStream.close();

		PaymentInitiationRequest signatureConfigBean = getSignatureDataConfigurationBean();

		MessageDigest messageDiest = MessageDigest.getInstance("SHA-256");
		byte[] messageDiestInput = messageDiest.digest(signatureConfigBean.getBytes());

		bufferInputStream = new BufferedInputStream(new ByteArrayInputStream(messageDiestInput));
		input = new byte[1024];
		length = 0;
		while ((length = bufferInputStream.read(input)) >= 0) {
			signatureAlgorithm.update(input, 0, length);
		}
		bufferInputStream.close();

		byte[] signatureInput = signatureAlgorithm.sign();
		String signature = Base64.encodeBase64String(signatureInput);
		System.out.println("Generated Signature:::" + signature);
		return signature;
	}

	public PaymentInitiationRequest getSignatureDataConfigurationBean() {
		PaymentInitiationRequest paymentInitiationRequest = new PaymentInitiationRequest();
		paymentInitiationRequest.setCreditorIBAN(creditorIBAN);
		paymentInitiationRequest.setAmount(amount);
		paymentInitiationRequest.setDebtorIBAN(debtorIBAN);
		paymentInitiationRequest.setCurrency(currency);
		paymentInitiationRequest.setEndToEndId(endToEndId);
		return paymentInitiationRequest;
	}

}
