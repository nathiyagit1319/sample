package com.pis.api.exception;

import com.pis.api.model.ErrorReasonCode;
/**
 * 
 * Class for SignatureValidationException
 *
 */
public class SignatureValidationException extends RuntimeException{
	private static final long serialVersionUID = 1L;
	private ErrorReasonCode errorReasonCode;
	private String errorMessage;
    public SignatureValidationException(ErrorReasonCode errorReasonCode,String errorMessage) {
    	this.errorReasonCode = errorReasonCode;
    	this.errorMessage=errorMessage;
    }
	
	public ErrorReasonCode getErrorReasonCode() {
		return errorReasonCode;
	}
	public String getErrorMessage() {
		return errorMessage;
	}

}
