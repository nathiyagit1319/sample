package com.pis.api.controller;

import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.SignatureException;
import java.security.cert.CertificateException;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.pis.api.exception.AmountLimitExceedsException;
import com.pis.api.model.PaymentAcceptedResponse;
import com.pis.api.model.PaymentInitiationRequest;
import com.pis.api.model.TransactionStatus;
import com.pis.api.service.PaymentInitiationService;

/**
 * This controller is used to handle the rest api calls.
 * 
 * @see {PaymentInitiationService
 *
 */
@RestController
@RequestMapping("/")
public class PaymentInitiationController {

	private static final Logger logger = LoggerFactory.getLogger(PaymentInitiationController.class);

	@Autowired
	private PaymentInitiationService paymentInitiationService;

	@Value("${message.limitexceeds}")
	String limitExceedsMessage;
	@Value("${message.signatureinvlid}")
	String signatureMessage;
	@Value("${message.certificateunknown}")
	String certificateMesssage;
	@Value("${message.ibaninvalid}")
	String ibanMessage;
	@Value("${value.dnname}")
	String dnName;

	/**
	 * Post method for initiate payment.
	 * 
	 * @param paymentInitiationRequest
	 * @param xRequestId
	 * @param signature
	 * @param signatureCertificate
	 * @return
	 * @throws AmountLimitExceedsException
	 * @throws CertificateException
	 * @throws InvalidKeyException
	 * @throws NoSuchAlgorithmException
	 * @throws SignatureException
	 * @throws IOException
	 */
	@PostMapping(value = "initiatepayment", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<PaymentAcceptedResponse> initiatePayment(
			@RequestBody PaymentInitiationRequest paymentInitiationRequest,
			@RequestHeader(value = "X-Request-Id") String xRequestId,
			@RequestHeader(value = "Signature") String signature,
			@RequestHeader(value = "Signature-Certificate") String signatureCertificate)
			throws AmountLimitExceedsException, CertificateException, InvalidKeyException, NoSuchAlgorithmException,
			SignatureException, IOException {
		/* validation for limit exceeds ,if failed return status code-422 */
		paymentInitiationService.validateLimitExceed(paymentInitiationRequest.getAmount(),
				paymentInitiationRequest.getDebtorIBAN());
		/* validation for iban digits ,if failed return status code-400 */
		paymentInitiationService.validateIbanDigits(paymentInitiationRequest.getDebtorIBAN(),
				paymentInitiationRequest.getCreditorIBAN());
		/* white listed certificate validation,if failed return status code-400 */
		paymentInitiationService.validateCertificate(signatureCertificate);
		/* Signature validation,if failed return status code-400 */
		paymentInitiationService.validateSignature(xRequestId, signature, signatureCertificate,
				paymentInitiationRequest);

		
		/* All validation and limit check passes - return status code-201 */
		PaymentAcceptedResponse paymentAcceptedResponse = new PaymentAcceptedResponse();
		paymentAcceptedResponse.setPaymentId(UUID.randomUUID());
		paymentAcceptedResponse.setStatus(TransactionStatus.ACCEPTED);
		logger.info(paymentAcceptedResponse.toString());
		return new ResponseEntity<PaymentAcceptedResponse>(paymentAcceptedResponse, HttpStatus.CREATED);

	}
}
