package com.pis.api;

import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.SignatureException;
import java.security.spec.InvalidKeySpecException;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.PropertySource;

//@SpringBootApplication
//@PropertySource(value = "file:D:/properties/application.properties")
public class PaymentInitiationApplication {

	public static void main(String[] args) {
		ApplicationContext applContext = SpringApplication.run(PaymentInitiationApplication.class, args);

//		SignatureGenerator signatureGeneratorbean = applContext.getBean(SignatureGenerator.class);
//		try {
//			String signature = signatureGeneratorbean.generateSignature();
//		} catch (InvalidKeyException | NoSuchAlgorithmException | InvalidKeySpecException | SignatureException
//				| IOException exception) {
//			exception.printStackTrace();
//		}
		
	}
}


