package com.pis.api.test;

import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.pis.api.controller.PaymentInitiationController;
import com.pis.api.exception.PaymentInitiationExceptionHandler;
import com.pis.api.model.PaymentInitiationRequest;
import com.pis.api.service.PaymentInitiationService;

@ExtendWith(SpringExtension.class)
@SpringBootTest
public class PaymentInitiationControllerTest {

	@InjectMocks
	private PaymentInitiationController paymentInitiationController;

	@Mock
	private PaymentInitiationService paymentInitiationService;

	private MockMvc mockMvc;

	@Autowired
	ObjectMapper objectMapper = new ObjectMapper();

	@Before
	public void setup() {
		MockitoAnnotations.initMocks(this);
		mockMvc = MockMvcBuilders.standaloneSetup(paymentInitiationController)
				.setControllerAdvice(new PaymentInitiationExceptionHandler()).build();
	}

	@Test
	public void validationSuccessTest() throws Exception {

		PaymentInitiationRequest paymentInitiationRequest = new PaymentInitiationRequest("NL02RABO7134384551",
				"NL94ABNA1008270121", "123.50", "EUR", "ID100023415");

		String jsonRequest = objectMapper.writeValueAsString(paymentInitiationRequest);
		MockHttpServletRequestBuilder builder = MockMvcRequestBuilders.post("/initiatepayment")
				.header("X-Request-Id", "29318e25-cebd-498c-888a-f77672f66449")
				.header("Signature",
						"ixL+Q/0TmyKREWudithNK+1JSuKDZ393FKHCqNEwbeimpGEhYso5bBrw8j81rtYt0bW+bOxOhaHPnXKnWJtPN6cfJP8m+hGRqdaovR0e6kZUa2p5WyDz611wBcFa7KuB2E/ocCXYYSMamqXnmOLLfC630pDWModkADMBDezKWGLx5ifqT8CFQ6ohFTmpIbzsmkioT8opZehbZRUCbj1ibbRVVL/kLw8bZLJJusjROYAr+E85E4I20rOaWYNZLrdIJL1r07OZkcYQrhDuRJQumxbL1aiMeOxwiSXDla31ATQyp8IdRrLWLs9cbgXerBBTSD9PobFi6ZDXxdJZ96KCoA==")
				.header("Signature-Certificate",
						"MIIDZTCCAk2gAwIBAgIEbnPTBDANBgkqhkiG9w0BAQsFADBjMQswCQYDVQQGEwI5MTETMBEGA1UECBMKVGFtaWwgTmFkdTEQMA4GA1UEBxMHY2hlbm5haTEMMAoGA1UEChMDcmFtMQswCQYDVQQLEwJJVDESMBAGA1UEAxMJbG9jYWxob3N0MB4XDTIwMDQyOTA0NTMxMVoXDTIwMDcyODA0NTMxMVowYzELMAkGA1UEBhMCOTExEzARBgNVBAgTClRhbWlsIE5hZHUxEDAOBgNVBAcTB2NoZW5uYWkxDDAKBgNVBAoTA3JhbTELMAkGA1UECxMCSVQxEjAQBgNVBAMTCWxvY2FsaG9zdDCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAKg8Mr0sEhgE5ZrKvp76Va4MUGvT2vWHMq5a06W5es62LoFrlMIO/CYewDczSEmfEjeMH9xcvdr3g/1we/4kbefUn9qvmmYj57Tcw4FjLI5dWZLvo/5cCH0e9y2V+kpwPnXStn+/VOIZW5SsaMpSSXP2hBEYSOlsf7mdhi0narwMNzXHgWCsFUgD+AxLDgj4nsmsNuLm7t0SzEtWxRvHSqMOyZS0IbHBRGvkMk7kr3bFNdHnNTuTSincfPSMnovl9rJx4hA/eBUW5J56awC8XZFTL4YycVKzDHTDUVzBF3o82hzoWMQ/S/u567Wt75G07NrmtIrdYzjUgJEcARMZNzsCAwEAAaMhMB8wHQYDVR0OBBYEFD1FixNCu950Z5Wt4nMH5hskoiLqMA0GCSqGSIb3DQEBCwUAA4IBAQBW9TGv2tSpZQ+ss+OykwiQRYnMtKXT9rOU7av7k+Mj0lI83hAJLHvhYSQpvv9HrjR72Wh+6q5x4pCgWOn5EMyEXEuoPRJ6+ingN3k5wbx89LXq1cXV1jY+2Q2/0S6xXm/t0ut54xadBfyRjQwPV7VUe7GkLah2rsiox9PQ8XJEWIB8u5cfT8wepbtMlwuyhMAhbwH99v8b/7a5AYCIN71NP2DKrodWi3MO8QMu9s2aRhkQqosvc03h+iyYkkUbXxjyJsU+maPxx/yArWbQxu9/YgQU1AWiCqldBapRKU9eAjp8xA22Bt2xq1bT0d1usw5J4Mg9foHNJat/IFyH9RLO")
				.content(jsonRequest).accept(MediaType.APPLICATION_JSON_VALUE)
				.contentType(MediaType.APPLICATION_JSON_VALUE);
		this.mockMvc.perform(builder).andExpect(MockMvcResultMatchers.status().isCreated())
				.andDo(MockMvcResultHandlers.print());

	}

}
