package com.pis.api.test;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.SignatureException;
import java.security.spec.InvalidKeySpecException;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.rules.ExpectedException;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.util.ReflectionTestUtils;

import com.pis.api.SignatureGenerator;


@ExtendWith(MockitoExtension.class)
@TestPropertySource
public class SignatureGeneratorTest {

	@InjectMocks
	private SignatureGenerator signatureGenerator;

	@Rule
	public final ExpectedException expected = ExpectedException.none();


	@Before
	public void setup() {
		MockitoAnnotations.initMocks(this);
		ReflectionTestUtils.setField(signatureGenerator, "xRequestId", "29318e25-cebd-498c-888a-f77672f66449");
		ReflectionTestUtils.setField(signatureGenerator, "privateKey",
				"MIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQCoPDK9LBIYBOWayr6e+lWuDFBr09r1hzKuWtOluXrOti6Ba5TCDvwmHsA3M0hJnxI3jB/cXL3a94P9cHv+JG3n1J/ar5pmI+e03MOBYyyOXVmS76P+XAh9HvctlfpKcD510rZ/v1TiGVuUrGjKUklz9oQRGEjpbH+5nYYtJ2q8DDc1x4FgrBVIA/gMSw4I+J7JrDbi5u7dEsxLVsUbx0qjDsmUtCGxwURr5DJO5K92xTXR5zU7k0op3Hz0jJ6L5fayceIQP3gVFuSeemsAvF2RUy+GMnFSswx0w1FcwRd6PNoc6FjEP0v7ueu1re+RtOza5rSK3WM41ICRHAETGTc7AgMBAAECggEAMKcgIVdCcFHSOP7TO9S3vJrxEw30r7cGsCeyN6Y5XtiPAHylS63bvAZ+njgleq0XLptGh4sGmPGl6UCDi07rvfTeufa41zshAkwp+hw9QXq7seO98IybI9w1rahG9woY9igXAUDLAoxE0O0/bOt5NKEhNnRoeaEYGwz0RdC1bGY/2dFJVf7ao/B2ef3S/LeKwbAIvBUBMKS99eD84tjstg4AsXA0o408D3hb+Q50g5PZVDHHRhybzs1vovq0z8k6CihO7el/mwIOCMsxrTaxX2PyoSpHm5W6+eQri4GL6PgC1S/hYD2Ul4QSSZESsFGVJG5d4iOZmL/TmA+ipE1JyQKBgQDYVvYCMRnb5j/Yl2Y1WjlDxNcmStlAne8FGgwCNkokJLXUeDTf33opT4LjkHsRP0NEc+l5ft5d7bEhRzcFcz5s5tF5LPsQgfJH4bgjCDx5ggwnVIdLxuejZ1sWHVgUIuPH5zePjhrDLMX2G1SNAkj5wZZ5gX2OY10qD0GHcbMPRwKBgQDHE6SLCo8mQjZOZrGkLFfDYpZ+htJoZ/xzZk7e4qepxPB/OpsUqC2HWOLgDCrJ8Fjo1/VyeeOChd/SDDQd5DS0CllOo/eYo6PH72FjbNTJ3khsR7Mo0Q3s3Bc8q5nO/oa9xjGAQg56xfLCiZhyOSJ6cJbhydSXHX5pN1FzG32abQKBgAajbHsWvJ9lylHAG4/Ji/ZLZPq000PLVNlIOlQbDF1djwLNCXpRJjN8UBzhgxU9ZrgEAocK4JHrSEMoJ0UQizrWPllEixOvmRqhj3/rscdcuTi/vEMUAGmgM0hTcC91/p1Ut/y8tI+GoTBzGD4XctvPF+n0kkC7RdGTlEQutfrjAoGAUNlxYeaP7IHHfF/IlVxM6FUJuakXmr9gj51lOq/iV9hbs9AhW2pR0z4OJd/LIOgzs5zBWhSWiVPFapD6OYmMvfHWA1IkJCGRSom1i6OPZ8yWrSMRZ+o/NYrNBR7MAHzuS/RJ9kTdjI8H4GnxN7Jshj1jiZ9mb1jTFfgZZB4uDKECgYEAzO/MO0JkPKDLCGde5jtvgs3UOD/VuMFA2mDcUSw30gsRqoPLytnYUPOiL8tvaJ2DHeOQMYOkfMcSQBvUJD7axlPpj5AmAI2R5qXeN40aZrQwst0Z7L9S6YZqIZiut19YLoB//kUqHmnormSyn05g5eE/QfyplvdTxdVAemSu3rA=");
		ReflectionTestUtils.setField(signatureGenerator, "debtorIBAN", "NL02RABO7134384551");
		ReflectionTestUtils.setField(signatureGenerator, "creditorIBAN", "NL94ABNA1008270121");
		ReflectionTestUtils.setField(signatureGenerator, "amount", "123.50");
		ReflectionTestUtils.setField(signatureGenerator, "currency", "EUR");
		ReflectionTestUtils.setField(signatureGenerator, "endToEndId", "ID100023415");

	}

	@Test
	public void generateSignatureTest() throws InvalidKeyException, NoSuchAlgorithmException, InvalidKeySpecException,
			SignatureException, IOException {
		System.out.println(signatureGenerator.generateSignature());
		String s = signatureGenerator.generateSignature();
		assertEquals(
				"ixL+Q/0TmyKREWudithNK+1JSuKDZ393FKHCqNEwbeimpGEhYso5bBrw8j81rtYt0bW+bOxOhaHPnXKnWJtPN6cfJP8m+hGRqdaovR0e6kZUa2p5WyDz611wBcFa7KuB2E/ocCXYYSMamqXnmOLLfC630pDWModkADMBDezKWGLx5ifqT8CFQ6ohFTmpIbzsmkioT8opZehbZRUCbj1ibbRVVL/kLw8bZLJJusjROYAr+E85E4I20rOaWYNZLrdIJL1r07OZkcYQrhDuRJQumxbL1aiMeOxwiSXDla31ATQyp8IdRrLWLs9cbgXerBBTSD9PobFi6ZDXxdJZ96KCoA==",
				s);
	}
}
