package com.pis.api.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.SignatureException;
import java.security.cert.CertificateException;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.rules.ExpectedException;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.util.ReflectionTestUtils;

import com.pis.api.exception.AmountLimitExceedsException;
import com.pis.api.exception.SignatureValidationException;
import com.pis.api.model.PaymentInitiationRequest;
import com.pis.api.service.PaymentInitiationService;

@ExtendWith(SpringExtension.class)
@TestPropertySource
public class PaymentInitiationServiceTest {

	@InjectMocks
	private PaymentInitiationService paymentInitiationService;

	@Rule
	public final ExpectedException expected = ExpectedException.none();

	@Autowired
	private PaymentInitiationRequest paymentInitiationRequest;

	@Before
	public void setup() {
		MockitoAnnotations.initMocks(this);
		ReflectionTestUtils.setField(paymentInitiationService, "limitExceedsMessage",
				"LIMIT_EXCEEDED due to the balance of the account or other reasons");
		ReflectionTestUtils.setField(paymentInitiationService, "signatureMessage", "Signature is invalid");
		ReflectionTestUtils.setField(paymentInitiationService, "certificateMesssage", "Certificate is unknown");
		ReflectionTestUtils.setField(paymentInitiationService, "ibanMessage", "iban is invalid");
		ReflectionTestUtils.setField(paymentInitiationService, "ibanPattern", "[A-Z]{2}[0-9]{2}[a-zA-Z0-9]{1,30}");
		ReflectionTestUtils.setField(paymentInitiationService, "ibanMaxLength", "34");
		ReflectionTestUtils.setField(paymentInitiationService, "domainName", "localhos");
	}

	@Test
	public void verifiesTypeAndMessage() {
		AmountLimitExceedsException exception = assertThrows(AmountLimitExceedsException.class,
				() -> paymentInitiationService.validateLimitExceed("123.50", "NL02RABO713438455666"));
		assertEquals("LIMIT_EXCEEDED due to the balance of the account or other reasons", exception.getErrorMessage());
	}

	@Test(expected = AmountLimitExceedsException.class)
	public void limitExceedsValidationTest() {
		paymentInitiationService.validateLimitExceed("123.50", "NL02RABO713438455666");
	}

	@Test
	public void ibanValidationTest() {
		expected.expect(SignatureValidationException.class);
		paymentInitiationService.validateIbanDigits("N802RABO713438455666", "NL02RABO713438455566");
	}

	@Test
	public void checkPatternMatchesTest() {
		assertEquals(paymentInitiationService.checkPatternMatches("NL02RABO713438455666", "NL02RABO713438455566"),
				true);
	}

	@Test
	public void signatureValidationTest() throws InvalidKeyException, CertificateException, NoSuchAlgorithmException,
			SignatureException, IOException {
		paymentInitiationRequest = new PaymentInitiationRequest("NL02RABO7134384551", "NL94ABNA1008270121", "123.50",
				"EUR", "ID100023415");
		String xRequestId = "29318e25-cebd-498c-888a-f77672f6649";
		String signature = "ixL+Q/0TmyKREWudithNK+1JSuKDZ393FKHCqNEwbeimpGEhYso5bBrw8j81rtYt0bW+bOxOhaHPnXKnWJtPN6cfJP8m+hGRqdaovR0e6kZUa2p5WyDz611wBcFa7KuB2E/ocCXYYSMamqXnmOLLfC630pDWModkADMBDezKWGLx5ifqT8CFQ6ohFTmpIbzsmkioT8opZehbZRUCbj1ibbRVVL/kLw8bZLJJusjROYAr+E85E4I20rOaWYNZLrdIJL1r07OZkcYQrhDuRJQumxbL1aiMeOxwiSXDla31ATQyp8IdRrLWLs9cbgXerBBTSD9PobFi6ZDXxdJZ96KCoA==";
		String signatureCertificate = "MIIDZTCCAk2gAwIBAgIEbnPTBDANBgkqhkiG9w0BAQsFADBjMQswCQYDVQQGEwI5MTETMBEGA1UECBMKVGFtaWwgTmFkdTEQMA4GA1UEBxMHY2hlbm5haTEMMAoGA1UEChMDcmFtMQswCQYDVQQLEwJJVDESMBAGA1UEAxMJbG9jYWxob3N0MB4XDTIwMDQyOTA0NTMxMVoXDTIwMDcyODA0NTMxMVowYzELMAkGA1UEBhMCOTExEzARBgNVBAgTClRhbWlsIE5hZHUxEDAOBgNVBAcTB2NoZW5uYWkxDDAKBgNVBAoTA3JhbTELMAkGA1UECxMCSVQxEjAQBgNVBAMTCWxvY2FsaG9zdDCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAKg8Mr0sEhgE5ZrKvp76Va4MUGvT2vWHMq5a06W5es62LoFrlMIO/CYewDczSEmfEjeMH9xcvdr3g/1we/4kbefUn9qvmmYj57Tcw4FjLI5dWZLvo/5cCH0e9y2V+kpwPnXStn+/VOIZW5SsaMpSSXP2hBEYSOlsf7mdhi0narwMNzXHgWCsFUgD+AxLDgj4nsmsNuLm7t0SzEtWxRvHSqMOyZS0IbHBRGvkMk7kr3bFNdHnNTuTSincfPSMnovl9rJx4hA/eBUW5J56awC8XZFTL4YycVKzDHTDUVzBF3o82hzoWMQ/S/u567Wt75G07NrmtIrdYzjUgJEcARMZNzsCAwEAAaMhMB8wHQYDVR0OBBYEFD1FixNCu950Z5Wt4nMH5hskoiLqMA0GCSqGSIb3DQEBCwUAA4IBAQBW9TGv2tSpZQ+ss+OykwiQRYnMtKXT9rOU7av7k+Mj0lI83hAJLHvhYSQpvv9HrjR72Wh+6q5x4pCgWOn5EMyEXEuoPRJ6+ingN3k5wbx89LXq1cXV1jY+2Q2/0S6xXm/t0ut54xadBfyRjQwPV7VUe7GkLah2rsiox9PQ8XJEWIB8u5cfT8wepbtMlwuyhMAhbwH99v8b/7a5AYCIN71NP2DKrodWi3MO8QMu9s2aRhkQqosvc03h+iyYkkUbXxjyJsU+maPxx/yArWbQxu9/YgQU1AWiCqldBapRKU9eAjp8xA22Bt2xq1bT0d1usw5J4Mg9foHNJat/IFyH9RLO";

		expected.expect(SignatureValidationException.class);
		paymentInitiationService.validateSignature(xRequestId, signature, signatureCertificate,
				paymentInitiationRequest);
	}

	@Test
	public void certificateValidationTest() throws InvalidKeyException, CertificateException, NoSuchAlgorithmException,
			SignatureException, IOException, NullPointerException {
		String signatureCertificate = "MIIDZTCCAk2gAwIBAgIEbnPTBDANBgkqhkiG9w0BAQsFADBjMQswCQYDVQQGEwI5MTETMBEGA1UECBMKVGFtaWwgTmFkdTEQMA4GA1UEBxMHY2hlbm5haTEMMAoGA1UEChMDcmFtMQswCQYDVQQLEwJJVDESMBAGA1UEAxMJbG9jYWxob3N0MB4XDTIwMDQyOTA0NTMxMVoXDTIwMDcyODA0NTMxMVowYzELMAkGA1UEBhMCOTExEzARBgNVBAgTClRhbWlsIE5hZHUxEDAOBgNVBAcTB2NoZW5uYWkxDDAKBgNVBAoTA3JhbTELMAkGA1UECxMCSVQxEjAQBgNVBAMTCWxvY2FsaG9zdDCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAKg8Mr0sEhgE5ZrKvp76Va4MUGvT2vWHMq5a06W5es62LoFrlMIO/CYewDczSEmfEjeMH9xcvdr3g/1we/4kbefUn9qvmmYj57Tcw4FjLI5dWZLvo/5cCH0e9y2V+kpwPnXStn+/VOIZW5SsaMpSSXP2hBEYSOlsf7mdhi0narwMNzXHgWCsFUgD+AxLDgj4nsmsNuLm7t0SzEtWxRvHSqMOyZS0IbHBRGvkMk7kr3bFNdHnNTuTSincfPSMnovl9rJx4hA/eBUW5J56awC8XZFTL4YycVKzDHTDUVzBF3o82hzoWMQ/S/u567Wt75G07NrmtIrdYzjUgJEcARMZNzsCAwEAAaMhMB8wHQYDVR0OBBYEFD1FixNCu950Z5Wt4nMH5hskoiLqMA0GCSqGSIb3DQEBCwUAA4IBAQBW9TGv2tSpZQ+ss+OykwiQRYnMtKXT9rOU7av7k+Mj0lI83hAJLHvhYSQpvv9HrjR72Wh+6q5x4pCgWOn5EMyEXEuoPRJ6+ingN3k5wbx89LXq1cXV1jY+2Q2/0S6xXm/t0ut54xadBfyRjQwPV7VUe7GkLah2rsiox9PQ8XJEWIB8u5cfT8wepbtMlwuyhMAhbwH99v8b/7a5AYCIN71NP2DKrodWi3MO8QMu9s2aRhkQqosvc03h+iyYkkUbXxjyJsU+maPxx/yArWbQxu9/YgQU1AWiCqldBapRKU9eAjp8xA22Bt2xq1bT0d1usw5J4Mg9foHNJat/IFyH9RLO";
		expected.expect(SignatureValidationException.class);
		paymentInitiationService.validateCertificate(signatureCertificate);
	}

}
