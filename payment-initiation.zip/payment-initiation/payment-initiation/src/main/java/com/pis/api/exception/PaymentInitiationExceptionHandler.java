package com.pis.api.exception;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;
import com.pis.api.model.ErrorReasonCode;
import com.pis.api.model.PaymentRejectedResponse;
import com.pis.api.model.TransactionStatus;

/**
 * 
 * Class for Custom and Global exception handliing
 *
 */
@ControllerAdvice
public class PaymentInitiationExceptionHandler extends ResponseEntityExceptionHandler {
	PaymentRejectedResponse payRejectedResponse = null;
	private static final Logger logger = LoggerFactory.getLogger(PaymentInitiationExceptionHandler.class);

	@ExceptionHandler(value = { AmountLimitExceedsException.class })
	public ResponseEntity<PaymentRejectedResponse> handleLimitExceedException(AmountLimitExceedsException exception,
			WebRequest request) {
		payRejectedResponse = new PaymentRejectedResponse();
		payRejectedResponse.setStatus(TransactionStatus.REJECTED);
		payRejectedResponse.setReasonCode(exception.getErrorReasonCode());
		payRejectedResponse.setReason(exception.getErrorMessage());
		logger.info(payRejectedResponse.toString());
		return new ResponseEntity<PaymentRejectedResponse>(payRejectedResponse, HttpStatus.UNPROCESSABLE_ENTITY);
	}

	@ExceptionHandler(value = { SignatureValidationException.class })
	public ResponseEntity<PaymentRejectedResponse> handleValidationException(SignatureValidationException exception,
			WebRequest request) {
		payRejectedResponse = new PaymentRejectedResponse();
		payRejectedResponse.setStatus(TransactionStatus.REJECTED);
		payRejectedResponse.setReasonCode(exception.getErrorReasonCode());
		payRejectedResponse.setReason(exception.getErrorMessage());
		logger.info(payRejectedResponse.toString());
		return new ResponseEntity<PaymentRejectedResponse>(payRejectedResponse, HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(value = { Exception.class })
	public ResponseEntity<PaymentRejectedResponse> handleValidationException(Exception exception, WebRequest request) {
		payRejectedResponse = new PaymentRejectedResponse();
		payRejectedResponse.setStatus(TransactionStatus.REJECTED);
		payRejectedResponse.setReasonCode(ErrorReasonCode.GENERAL_ERROR);
		payRejectedResponse.setReason(exception.getMessage());
		logger.info(payRejectedResponse.toString());
		logger.info(exception.getMessage());
		return new ResponseEntity<PaymentRejectedResponse>(payRejectedResponse, HttpStatus.INTERNAL_SERVER_ERROR);
	}

}
