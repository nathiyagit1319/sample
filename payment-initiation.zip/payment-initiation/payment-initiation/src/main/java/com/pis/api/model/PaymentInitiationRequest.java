package com.pis.api.model;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Bean for payment initiation request
 */
public class PaymentInitiationRequest {

	public PaymentInitiationRequest(String debtorIBAN, String creditorIBAN, String amount,
			@Pattern(regexp = "[A-Z]{3}") String currency, String endToEndId) {
		super();
		this.debtorIBAN = debtorIBAN;
		this.creditorIBAN = creditorIBAN;
		this.amount = amount;
		this.currency = currency;
		this.endToEndId = endToEndId;
	}

	public PaymentInitiationRequest() {
		// TODO Auto-generated constructor stub
	}

	@JsonProperty("debtorIBAN")
	// @Pattern(regexp = "[A-Z]{2}[0-9]{2}[a-zA-Z0-9]{1,30}")
	private String debtorIBAN;

	@JsonProperty("creditorIBAN")
	// @Pattern(regexp = "[A-Z]{2}[0-9]{2}[a-zA-Z0-9]{1,30}")
	private String creditorIBAN;

	@JsonProperty("amount")
	private String amount;

	@JsonProperty("currency")
	@Pattern(regexp = "[A-Z]{3}")
	private String currency = "EUR";

	@JsonProperty("endToEndId")
	private String endToEndId;

	/**
	 * Get debtorIBAN
	 * 
	 * @return debtorIBAN
	 */
	@NotNull
	public String getDebtorIBAN() {
		return debtorIBAN;
	}

	public void setDebtorIBAN(String debtorIBAN) {
		this.debtorIBAN = debtorIBAN;
	}

	/**
	 * Get creditorIBAN
	 * 
	 * @return creditorIBAN
	 */
	@NotNull
	public String getCreditorIBAN() {
		return creditorIBAN;
	}

	public void setCreditorIBAN(String creditorIBAN) {
		this.creditorIBAN = creditorIBAN;
	}

	/**
	 * Amount of the payment initiation
	 * 
	 * @return amount
	 */
	@NotNull
	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	/**
	 * Get currency
	 * 
	 * @return currency
	 */
	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	/**
	 * Unique identifier per payment initiation request provided by the client
	 * 
	 * @return endToEndId
	 */

	@NotNull
	public String getEndToEndId() {
		return endToEndId;
	}

	public void setEndToEndId(String endToEndId) {
		this.endToEndId = endToEndId;
	}

	public byte[] getBytes() throws IOException {

		ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
		outputStream.write(debtorIBAN.getBytes());
		outputStream.write(creditorIBAN.getBytes());
		outputStream.write(amount.getBytes());
		outputStream.write(currency.getBytes());
		outputStream.write(endToEndId.getBytes());
		return outputStream.toByteArray();
	}
}