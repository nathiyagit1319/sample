package com.pis.api.service;

import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.security.InvalidKeyException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.PublicKey;
import java.security.Signature;
import java.security.SignatureException;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.util.regex.Pattern;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import com.pis.api.exception.AmountLimitExceedsException;
import com.pis.api.exception.SignatureValidationException;
import com.pis.api.model.ErrorReasonCode;
import com.pis.api.model.PaymentInitiationRequest;

/**
 * 
 * Implementing the business logic in service level
 *
 */
@Service
public class PaymentInitiationService {

	@Value("${message.limitexceeds}")
	String limitExceedsMessage;
	@Value("${message.signatureinvlid}")
	String signatureMessage;
	@Value("${message.certificateunknown}")
	String certificateMesssage;
	@Value("${message.ibaninvalid}")
	String ibanMessage;
	@Value("${value.dnname}")
	String domainName;
	@Value("${value.ibanpattern}")
	String ibanPattern;
	@Value("${value.ibanmaxlength}")
	String ibanMaxLength;

	private static final Logger logger = LoggerFactory.getLogger(PaymentInitiationService.class);

	/**
	 * Validation for limit exceeds
	 * 
	 * @param amount
	 * @param debtorIBAN
	 * @throws AmountLimitExceedsException
	 */
	public void validateLimitExceed(@NotNull String amount, @NotNull String debtorIBAN)
			throws AmountLimitExceedsException {
		int sumOfDigits = 0;
		if (new BigDecimal(amount).intValue() > 0 && StringUtils.isNotBlank(debtorIBAN)) {
			sumOfDigits = debtorIBAN.chars().filter(Character::isDigit).map(Character::getNumericValue).sum();
		}

		if ((sumOfDigits % debtorIBAN.length()) == 0) {
			logger.info("AmountLimitExceedsException thrown" + limitExceedsMessage);
			throw new AmountLimitExceedsException(ErrorReasonCode.LIMIT_EXCEEDED, limitExceedsMessage);
		}
	}

	/**
	 * validation for iban digits
	 * 
	 * @param debtorIBAN
	 * @param creditorIBAN
	 */
	public void validateIbanDigits(@NotNull String debtorIBAN, @NotNull String creditorIBAN) {
		if (!checkPatternMatches(debtorIBAN, creditorIBAN)) {
			logger.info("SignatureValidationException thrown" + ibanMessage);
			throw new SignatureValidationException(ErrorReasonCode.INVALID_REQUEST, ibanMessage);
		}
	}

	public boolean checkPatternMatches(@NotNull String debtorIBAN, @NotNull String creditorIBAN) {
		if ((Pattern.matches(ibanPattern, debtorIBAN) && debtorIBAN.length() <= Integer.parseInt(ibanMaxLength))
				&& (Pattern.matches(ibanPattern, creditorIBAN)
						&& creditorIBAN.length() <= Integer.parseInt(ibanMaxLength))) {
			return true;
		}
		return false;
	}

	/**
	 * validation for white listing certificate
	 * 
	 * @param signatureCertificate
	 * @throws CertificateException
	 */
	public void validateCertificate(String signatureCertificate) throws CertificateException {
		String commonName = null;
		X509Certificate certificate = getCertificate(signatureCertificate);
		for (String domainName : certificate.getSubjectDN().getName().split(",\\s*")) {
			if (domainName.startsWith("CN=")) {
				commonName = domainName.substring(3);
			}
		}
		if (!StringUtils.equals(domainName, commonName)) {
			logger.info("SignatureValidationException thrown" + certificateMesssage);
			throw new SignatureValidationException(ErrorReasonCode.UNKNOWN_CERTIFICATE, certificateMesssage);
		}
	}

	/**
	 * validate signature
	 * 
	 * @param xRequestId
	 * @param signatureString
	 * @param signatureCertificate
	 * @param paymentInitiationRequest
	 * @throws CertificateException
	 * @throws NoSuchAlgorithmException
	 * @throws InvalidKeyException
	 * @throws SignatureException
	 * @throws IOException
	 */
	public void validateSignature(String xRequestId, String signature, String signatureCertificate,
			@Valid PaymentInitiationRequest paymentInitiationRequest) throws CertificateException,
			NoSuchAlgorithmException, InvalidKeyException, SignatureException, IOException {

		PublicKey publicKey = getPublicKey(signatureCertificate);
		Signature signatureAlgorithm = Signature.getInstance("SHA256withRSA");
		signatureAlgorithm.initVerify(publicKey);

		byte[] signaturInput = Base64.decodeBase64(signature);

		BufferedInputStream bufferInputStream = new BufferedInputStream(
				new ByteArrayInputStream(xRequestId.getBytes()));
		byte[] input = new byte[1024];
		int length;
		while ((length = bufferInputStream.read(input)) >= 0) {
			signatureAlgorithm.update(input, 0, length);
		}
		bufferInputStream.close();

		MessageDigest messageDigest = MessageDigest.getInstance("SHA-256");
		byte[] messageDigestInput = messageDigest.digest(paymentInitiationRequest.getBytes());

		bufferInputStream = new BufferedInputStream(new ByteArrayInputStream(messageDigestInput));
		input = new byte[1024];
		length = 0;
		while ((length = bufferInputStream.read(input)) >= 0) {
			signatureAlgorithm.update(input, 0, length);
		}
		bufferInputStream.close();

		if (!signatureAlgorithm.verify(signaturInput)) {
			logger.info("SignatureValidationException thrown" + signatureMessage);
			throw new SignatureValidationException(ErrorReasonCode.INVALID_SIGNATURE, signatureMessage);
		}

	}

	private static X509Certificate getCertificate(String certificate) throws CertificateException {
		CertificateFactory certificateFactory = CertificateFactory.getInstance("X.509");
		return (X509Certificate) certificateFactory
				.generateCertificate(new ByteArrayInputStream(Base64.decodeBase64(certificate.getBytes())));
	}

	private static PublicKey getPublicKey(String certificate) throws CertificateException {
		return getCertificate(certificate).getPublicKey();
	}

}
