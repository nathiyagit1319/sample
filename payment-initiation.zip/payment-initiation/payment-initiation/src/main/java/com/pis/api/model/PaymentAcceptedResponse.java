package com.pis.api.model;

import java.util.UUID;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Bean for PaymentAcceptedResponse.
 */

public class PaymentAcceptedResponse {

	@Override
	public String toString() {
		return "PaymentAcceptedResponse [paymentId=" + paymentId + ", status=" + status + "]";
	}

	@JsonProperty("paymentId")
	private UUID paymentId;

	@JsonProperty("status")
	private TransactionStatus status = null;

	/**
	 * Get paymentId
	 * 
	 * @return paymentId
	 */
	@NotNull
	@Valid
	public UUID getPaymentId() {
		return paymentId;
	}

	/**
	 * 
	 * @param paymentId
	 */
	public void setPaymentId(UUID paymentId) {
		this.paymentId = paymentId;
	}

	/**
	 * Get status
	 * 
	 * @return status
	 */
	@NotNull
	@Valid
	public TransactionStatus getStatus() {
		return status;
	}

	/**
	 * 
	 * @param status
	 */
	public void setStatus(TransactionStatus status) {
		this.status = status;
	}

}
