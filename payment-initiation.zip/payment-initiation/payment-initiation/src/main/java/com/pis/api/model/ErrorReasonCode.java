package com.pis.api.model;

import com.fasterxml.jackson.annotation.JsonValue;

/**
 * Enum for ErrorReasonCode
 */
public enum ErrorReasonCode {

	UNKNOWN_CERTIFICATE("UNKNOWN_CERTIFICATE"),

	INVALID_SIGNATURE("INVALID_SIGNATURE"),

	INVALID_REQUEST("INVALID_REQUEST"),

	LIMIT_EXCEEDED("LIMIT_EXCEEDED"),

	GENERAL_ERROR("GENERAL_ERROR");

	private String value;

	ErrorReasonCode(String value) {
		this.value = value;
	}

	@Override
	@JsonValue
	public String toString() {
		return String.valueOf(value);
	}

}
