package com.pis.api.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * Bean for Payment rejected response
 */

public class PaymentRejectedResponse {
	

	@JsonProperty("status")
	private TransactionStatus status = null;
	@JsonProperty("reason")
	private String reason;

	@JsonProperty("reasonCode")
	private ErrorReasonCode reasonCode = null;

	/**
	 * Get status
	 * 
	 * @return status
	 */

	@NotNull
	@Valid
	public TransactionStatus getStatus() {
		return status;
	}

	public void setStatus(TransactionStatus status) {
		this.status = status;
	}

	/**
	 * Human readable reason of the rejection
	 * 
	 * @return reason
	 */
	@NotNull
	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

//	public PaymentRejectedResponse reasonCode(ErrorReasonCode reasonCode) {
//		this.reasonCode = reasonCode;
//		return this;
//	}

	/**
	 * Get reasonCode
	 * 
	 * @return reasonCode
	 */
	@NotNull
	@Valid
	public ErrorReasonCode getReasonCode() {
		return reasonCode;
	}

	public void setReasonCode(ErrorReasonCode reasonCode) {
		this.reasonCode = reasonCode;
	}

	
	@Override
	public String toString() {
		return "PaymentRejectedResponse [status=" + status + ", reason=" + reason + ", reasonCode=" + reasonCode + "]";
	}
	
}
