package com.pis.api.model;

import com.fasterxml.jackson.annotation.JsonValue;

/**
 * Enum for Transaction status
 */
public enum TransactionStatus {

	ACCEPTED("Accepted"),

	REJECTED("Rejected");

	private String value;

	TransactionStatus(String value) {
		this.value = value;
	}

	@Override
	@JsonValue
	public String toString() {
		return String.valueOf(value);
	}
}
