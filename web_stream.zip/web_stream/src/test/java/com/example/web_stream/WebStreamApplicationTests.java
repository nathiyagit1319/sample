package com.example.web_stream;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.web.WebStreamApplication;

@SpringBootTest
class WebStreamApplicationTests {

	@Test
	void contextLoads() {
		
	}

	@Test
    public void applicationStarts() {
		WebStreamApplication.main(new String[] {});
    }
}
