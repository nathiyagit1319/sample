package com.example.web_stream;


import org.junit.Before;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.example.web.WebController;
import com.example.web.WebStreamApplication;

@ExtendWith(SpringExtension.class)
@SpringBootTest(classes = WebController.class)
public class WebControllerTest {

	 private MockMvc mockMvc;
	    @InjectMocks
	   private WebController webController;

	    

		@Before
		public void setup() {
			MockitoAnnotations.initMocks(this);
			mockMvc = MockMvcBuilders.standaloneSetup(webController).build();
		}

		 @Test
		    public void testIndexPage() throws Exception {
		    	MockHttpServletRequestBuilder builder = MockMvcRequestBuilders.get("/web");
		    	this.mockMvc.perform(builder).andExpect(MockMvcResultMatchers.view().name("index"));
		    }

    @Test
    public void testHomePage() throws Exception {
    	MockHttpServletRequestBuilder builder = MockMvcRequestBuilders.post("/saveDetails");
    	this.mockMvc.perform(builder).andExpect(MockMvcResultMatchers.view().name("home"));
    }
}
