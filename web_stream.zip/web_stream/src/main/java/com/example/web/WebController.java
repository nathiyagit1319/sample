package com.example.web;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

@Controller
@PropertySource(value="classpath:application.properties")
public class WebController {

	private static final Logger logger = LoggerFactory.getLogger(WebController.class);

	@Value("${spring.web.url}")
	private String webURL;

	@GetMapping("/web")
    public String getForm() {
		logger.info("Invoked getForm method....................");
        return "index";
    } 

	@PostMapping("/viewStream")                   
    public String saveDetails(@RequestParam(required=true) int noOfStream,ModelMap model) {
		try {
			
       model.addAttribute("noOfStream", noOfStream);
       model.addAttribute("webURL",webURL);
       logger.info("Invoked saveDetails method....."+"noOfStream:"+noOfStream+"::::::::webURL::::"+webURL);         
		}catch(Exception ex) {
			logger.error("Error occured in saveDetails method::"+ex.getMessage());
		}
		 return "home";
    }
}
